Welcome to the README file for Unix Shells by Example, 4/e, by Ellie Quigley
ISBN: 013147572X, copyright 2005, Prentice Hall PTR


System Requirements:
OPERATING SYSTEMS
Linux, Unix.


Contents:
This CD contains example files and data files in the following directories.  Each directory contains the example programs found in the corresponding book chapter:
chap02
chap03
chap04
chap05
chap06
chap07
chap08
chap09
chap10
chap11
chap12
chap13
chap14
chap15
chap16

Installation:
Insert the CD in your CDROM drive.
Mount the CDROM drive.
Navigate to the CD and execute the shell scripts.

Technical Support:
Prentice Hall PTR does not offer technical support for any of the programs on the CDROM.  However, if the CDROM is damaged, you may obtain a replacement copy by sending an email that describes the problem to: disc_exchange@prenhall.com
